/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.proyectoalgoritmo;

/**
 *
 * @author trejo
 */


public class ProyectoAlgoritmo {
    public static void main(String[] args) {
        InterfazGrafica interfaz = new InterfazGrafica();
        interfaz.setVisible(true);
    }

}